from ticktick_mcp.server import run


def main():
    run()
